-module(proyecto_cowboy_sup).
-behaviour(supervisor).

-export([start_link/0, init/1]).

start_link() ->
    supervisor:start_link({local, ?MODULE}, ?MODULE, []).

init([]) ->
    % Definir los hijos que serán supervisados (vacío por ahora)
    Children = [],
    % Estrategia de supervisión
    {ok, {{one_for_one, 5, 10}, Children}}.
