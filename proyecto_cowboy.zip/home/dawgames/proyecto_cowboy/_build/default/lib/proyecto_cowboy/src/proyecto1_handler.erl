-module(proyecto1_handler).
-export([init/2]).
-import(cowboy_req, [reply/4]).

init(Req, State) ->
    Body = <<"¡Hola, Mundo!">>,
    Req2 = cowboy_req:reply(200, #{
        <<"content-type">> => <<"text/plain">>
    }, Body, Req),
    {ok, Req2, State}.
