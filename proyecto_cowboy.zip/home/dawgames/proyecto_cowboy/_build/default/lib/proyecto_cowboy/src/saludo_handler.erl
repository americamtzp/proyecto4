-module(saludo_handler).
-export([init/2]).
-import(cowboy_req, [reply/4, parse_qs/1]).

init(Req, State) ->
    Qs = cowboy_req:parse_qs(Req),
    Nombre = case lists:keyfind(<<"nombre">>, 1, Qs) of
        false -> <<"desconocido">>;
        {_, Value} -> Value
    end,
    Body = <<"¡Hola, ", Nombre/binary, "!">>,
    Req2 = cowboy_req:reply(200, #{
        <<"content-type">> => <<"text/plain">>
    }, Body, Req),
    {ok, Req2, State}.
