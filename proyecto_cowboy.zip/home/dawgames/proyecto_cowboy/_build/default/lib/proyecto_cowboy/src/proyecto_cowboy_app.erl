-module(proyecto_cowboy_app).
-behaviour(application).

-export([start/2, stop/1]).

start(_Type, _Args) ->
    % Asegurarse de que Ranch y Cowboy estén iniciados
    {ok, _} = application:ensure_all_started(ranch),
    
    % Definir el router para las rutas
    Dispatch = cowboy_router:compile([
        {'_', [
            {"/", proyecto1_handler, []},
            {"/saludo", saludo_handler, []}
        ]}
    ]),

    % Iniciar el listener HTTP en el puerto 8080
    {ok, _} = cowboy:start_clear(http_listener, [{port, 8080}], #{
        env => #{dispatch => Dispatch}
    }),

    % Iniciar el supervisor de la aplicación
    proyecto_cowboy_sup:start_link().

stop(_State) ->
    ok.
