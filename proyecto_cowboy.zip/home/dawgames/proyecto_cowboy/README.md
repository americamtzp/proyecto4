proyecto_cowboy
=====

An OTP application

Build
-----

    $ rebar3 compile
